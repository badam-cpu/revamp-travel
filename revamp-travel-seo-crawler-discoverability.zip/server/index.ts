import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import { registerApiRoutes } from "./routes.js";
import { robotsTxtHandler } from "./robots.js";
import { sitemapHandler } from "./sitemap.js";
import { isCrawlerUserAgent } from "./botDetect.js";
import { renderForBot } from "./prerender.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(express.json({ limit: "1mb" }));

  // API routes are registered before static/catch-all so they always win.
  registerApiRoutes(app);

  // Dynamic robots.txt / sitemap.xml — exact-path routes, matched before
  // the wildcard bot-prerender middleware below regardless of caller.
  app.get("/robots.txt", robotsTxtHandler);
  app.get("/sitemap.xml", sitemapHandler);

  // Belt-and-suspenders noindex: robots.txt Disallow alone doesn't
  // de-index an already-linked page, so every response under these two
  // auth-gated paths also carries the header, regardless of user agent.
  app.use(["/dashboard", "/admin"], (_req, res, next) => {
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    next();
  });

  // Bot prerender middleware — see server/prerender.ts's header comment
  // for why this is hand-written HTML rather than a headless browser.
  // Only intercepts a known crawler UA on what looks like a page route;
  // everything else (real browsers, /api/*, static assets, /dashboard,
  // /admin) falls through unchanged to express.static / the SPA catch-all.
  app.get("*", async (req, res, next) => {
    if (req.path.startsWith("/api/")) return next();
    if (req.path === "/dashboard" || req.path.startsWith("/dashboard/") || req.path === "/admin" || req.path.startsWith("/admin/")) return next();
    const lastSegment = req.path.split("/").pop() || "";
    if (lastSegment.includes(".")) return next(); // hashed JS/CSS, images, favicon.ico, etc.
    if (!isCrawlerUserAgent(req.get("user-agent"))) return next();

    try {
      const origin = `${req.protocol}://${req.get("host")}`;
      const { status, body } = await renderForBot(req.path, origin);
      res.status(status).set("Content-Type", "text/html; charset=utf-8").send(body);
    } catch (err) {
      console.error("Bot prerender failed, falling back to the SPA shell:", err);
      next();
    }
  });

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all non-API routes
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api/")) return next();
    res.sendFile(path.join(staticPath, "index.html"));
  });

  // In dev this process only serves /api/* (Vite's dev server, proxying
  // /api to this port, handles everything else) — use API_PORT so it
  // doesn't collide with Vite's own port. In production it serves both
  // the built SPA and the API on a single PORT.
  const port = process.env.NODE_ENV === "production" ? process.env.PORT || 3000 : process.env.API_PORT || 3001;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
