# Apply: Google + AI-crawler discoverability

This delta makes the marketplace fully findable by Google and open to AI
crawlers (GPTBot, ClaudeBot, PerplexityBot, CCBot, and more — every one of
them, training bots included, per an explicit decision to allow everything
in `robots.txt`). It adds: a dynamic `robots.txt` and `sitemap.xml`, real
per-page meta/Open Graph/Twitter/JSON-LD tags, and — because the app is a
client-rendered SPA and most AI crawlers don't execute JavaScript — a
server-side prerenderer that hands those crawlers real HTML instead of an
empty page shell.

Every file in this zip is a **complete replacement** for the file at that
same path in your repo (six are brand-new: `shared/seo.ts`,
`server/botDetect.ts`, `server/prerender.ts`, `server/robots.ts`,
`server/sitemap.ts`, `client/src/hooks/useDocumentMeta.ts`). Overwrite in
place — do not hand-merge.

## 1. Apply the files

Copy every file in this zip into your repo at the matching path, preserving
directories:

```
shared/seo.ts                              (new)
server/botDetect.ts                         (new)
server/prerender.ts                         (new)
server/robots.ts                            (new)
server/sitemap.ts                           (new)
server/supabase.ts
server/index.ts
client/src/hooks/useDocumentMeta.ts          (new)
client/src/pages/Home.tsx
client/src/pages/Explore.tsx
client/src/pages/Tours.tsx
client/src/pages/MapPage.tsx
client/src/pages/ListingPage.tsx
client/src/pages/Plan.tsx
client/src/pages/Login.tsx
client/src/pages/Signup.tsx
client/src/pages/Dashboard.tsx
client/src/pages/AdminReview.tsx
CLAUDE.md
README.md
marketplace-spec.md
ENVIRONMENT.md
```

No new npm dependency and no new environment variable are introduced — the
prerenderer is hand-written HTML (no headless browser), and both
`/robots.txt`/`/sitemap.xml` derive their own origin from each incoming
request, so nothing needs configuring for your actual domain.

## 2. Rebuild and redeploy

```bash
pnpm install   # no new deps, but harmless to confirm
pnpm check
pnpm build
```

Both should pass clean. Redeploy as usual.

## 3. Verification checklist

Run `pnpm start` (or hit your real deployed URL) and work through these —
swap `http://localhost:3000` for your real domain if testing after deploy:

- [ ] `curl http://localhost:3000/robots.txt` — lists `User-agent: *` plus
      an explicit block for every crawler (Googlebot, GPTBot, ClaudeBot,
      PerplexityBot, CCBot, Twitterbot, etc.), `Disallow: /dashboard`,
      `Disallow: /admin`, and ends with a `Sitemap:` line pointing at your
      real domain.
- [ ] `curl http://localhost:3000/sitemap.xml` — lists the static routes
      plus one `<url>` per **published** listing (not drafts/pending ones).
- [ ] `curl -A "GPTBot" http://localhost:3000/` and
      `curl -A "ClaudeBot" http://localhost:3000/explore` and
      `curl -A "Twitterbot" http://localhost:3000/listing/<a-real-slug>` —
      each returns real headings, descriptions, and `<meta>`/JSON-LD tags in
      the raw HTML — **not** an empty `<div id="root">`.
- [ ] `curl -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
      http://localhost:3000/` (a normal browser UA) — still gets the plain
      SPA shell. Real visitors are completely unaffected by this change.
- [ ] `curl -I -A "GPTBot" http://localhost:3000/dashboard` — response
      carries `X-Robots-Tag: noindex, nofollow`, and the body is still the
      untouched SPA shell (never rendered operator content). Same for
      `/admin`.
- [ ] Open a real listing page in a normal browser and check the page
      source (view-source, not devtools) for `<title>`, `<meta
      name="description">`, `<link rel="canonical">`, and a
      `<script type="application/ld+json">` block — confirms
      `useDocumentMeta` is running client-side too.
- [ ] Paste a real listing's `/listing/<slug>` URL into a link-preview tool
      (e.g. Twitter's card validator, or Slack by pasting the link in a
      channel) and confirm a real title/description/image show up, not a
      blank preview.
- [ ] If you edit a listing's title/description to include `<script>` or
      `&`/`"` characters (as a one-off test, then revert), confirm
      `curl -A "GPTBot" http://localhost:3000/listing/<slug>` shows the
      escaped entities in the HTML — not a live `<script>` tag — and that
      the JSON-LD block contains no literal `</script>`.
- [ ] Submit `sitemap.xml` to Google Search Console (Sitemaps → add
      `https://yourdomain.com/sitemap.xml`) once deployed to a real domain,
      so Google picks up the change immediately rather than waiting for its
      next crawl.

If a curl check shows the SPA shell instead of rendered content for a known
bot UA, double-check `server/botDetect.ts`'s `KNOWN_BOTS` list still
contains that UA token, and that the request isn't hitting `/api/*`,
`/dashboard`, `/admin`, or a path with a dot in its last segment (all
deliberately excluded from prerendering — see `server/index.ts`).
